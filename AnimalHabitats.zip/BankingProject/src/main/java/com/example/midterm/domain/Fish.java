package com.example.midterm.domain;

import com.example.midterm.interfaces.Swimable;

public abstract class Fish extends Animal implements Swimable {
}
