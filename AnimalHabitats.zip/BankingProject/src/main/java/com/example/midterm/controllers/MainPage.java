package com.example.midterm.controllers;

import com.example.midterm.animal.Tiger;
import com.example.midterm.animal.Wolf;
import com.example.midterm.birds.Crow;
import com.example.midterm.birds.Ostrich;
import com.example.midterm.birds.Penguin;
import com.example.midterm.birds.Sparrow;
import com.example.midterm.domain.AnimalEntity;
import com.example.midterm.domain.Fish;
import com.example.midterm.fishes.Pike;
import com.example.midterm.fishes.Shark;
import com.example.midterm.generics.Aquarium;
import com.example.midterm.generics.Cage;
import com.example.midterm.generics.Cell;
import com.example.midterm.interfaces.Flyable;
import com.example.midterm.interfaces.Swimable;
import com.example.midterm.interfaces.Walkable;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class MainPage {

    ModelAndView mv = new ModelAndView("redirect:/");
    ModelAndView error = new ModelAndView("redirect:/error");
    ModelAndView full = new ModelAndView("redirect:/full");

    private Cage<Walkable> cageForTigers = new Cage<>(36.8);
    private double cageForTigersSize = 0;
    private int cageForTigersNumber = 0;

    private Cage<Walkable> cageForWolfs = new Cage<>(46.8);
    private double cageForWolfsSize = 0;
    private int cageForWolfsNumber = 0;

    private Cell<Flyable> birds = new Cell<>(61.5);
    private double birdsSize = 0;
    private int birdsNumber = 0;

    private Aquarium<Fish> fish = new Aquarium<>(40.3);
    private double fishSize = 0;
    private int fishNumber = 0;

    private Aquarium<Swimable> turtles = new Aquarium<>(32.7);
    private double turtlesSize = 0;
    private int turtlesNumber = 0;

    private Aquarium<Swimable> anyAqua = new Aquarium<>(74.2);
    private double anyAquaSize = 0;
    private int anyAquaNumber = 0;

    @GetMapping("/addCagesTigerForm")
    public String tigerForm(Model model){
        model.addAttribute("animal",new AnimalEntity());
        return "tiger";
    }


    @GetMapping("/addCagesWolfForm")
    public String wolfForm(Model model){
        model.addAttribute("animal",new AnimalEntity());
        return "wolf";
    }

    @GetMapping("/addCellForm")
    public String birdForm(Model model){
        model.addAttribute("bird",new AnimalEntity());
        return "bird";
    }

    @GetMapping("/addAquariumFishes")
    public String fishForm(Model model){
        model.addAttribute("fish",new AnimalEntity());
        return "fish";
    }

    @GetMapping("/addAquariumTurtles")
    public String turlesForm(Model model){
        model.addAttribute("turtles",new AnimalEntity());
        return "turtle";
    }

    @GetMapping("addAquariumAnyAnimals")
    public String anyForm(Model model){
        model.addAttribute("anyAqua",new AnimalEntity());
        return "anyAqua";
    }

    @PostMapping("addCageTiger")
    public ModelAndView addCageTiger(@ModelAttribute("animal") AnimalEntity animal) throws Exception {
        try {
            if (animal.getName().equalsIgnoreCase("Tiger")) {
                if(cageForTigersSize<45.3) {
                    cageForTigers.addAnimal(new Tiger());
                    cageForTigersSize+=15.1;
                    cageForTigersNumber+=1;
                    return mv;
                } else return full;
            } else return error;
        } catch (Exception e){
            return full;
        }
    }

    @PostMapping("/addCageWolf")
    public ModelAndView addCageWolf(@ModelAttribute("animal") AnimalEntity animal) throws Exception {
        try {
            if(animal.getName().equalsIgnoreCase("Wolf")) {
                if(cageForWolfsSize<36.3) {
                    cageForWolfs.addAnimal(new Wolf());
                    cageForWolfsSize+=12.1;
                    cageForWolfsNumber+=1;
                    return mv;
                } else return full;
            } else return error;
        } catch (Exception e) {
            return full;
        }
    }

    @PostMapping("addBird")
    public ModelAndView addBird(@ModelAttribute("bird") AnimalEntity animal) throws Exception {
        try {
            if(animal.getName().equalsIgnoreCase("Ostrich")){
                if(birdsSize<60.39) {
                    birds.addAnimal(new Ostrich());
                    birdsSize+=9.4;
                    birdsNumber+=1;
                    return mv;
                } else return full;
            } else if(animal.getName().equalsIgnoreCase("Crow")){
                if(birdsSize<60.39) {
                    birds.addAnimal(new Crow());
                    birdsSize+=6.6;
                    birdsNumber+=1;
                    return mv;
                } else return full;
            } else if(animal.getName().equalsIgnoreCase("Sparrow")){
                if(birdsSize<60.39) {
                    birds.addAnimal(new Sparrow());
                    birdsSize+=14.2;
                    birdsNumber+=1;
                    return mv;
                } else return full;
            } else return error;
        } catch (Exception e){
            return full;
        }
    }

    @PostMapping("addFish")
    public ModelAndView addFish(@ModelAttribute("fish") AnimalEntity animal) throws Exception {
        try {
            if(animal.getName().equalsIgnoreCase("Pike")){
                if(fishSize<34.6) {
                    fish.addAnimal(new Pike());
                    fishSize+=7.5;
                    fishNumber+=1;
                    return mv;
                } else return full;
            } else if(animal.getName().equalsIgnoreCase("Shark")){
                if(fishSize<34.6) {
                    fish.addAnimal(new Shark());
                    fishSize+=9.8;
                    fishNumber+=1;
                    return mv;
                } else return full;
            } else return error;
        }
        catch (Exception e) {
            return full;
        }
    }

    @PostMapping("/addTurtles")
    public ModelAndView addTurtles(@ModelAttribute("turtles") AnimalEntity animal) throws Exception{
        try {
            if(animal.getName().equalsIgnoreCase("Turtle")){
                if(turtlesSize<39.6) {
                    turtles.addAnimal(new Penguin());
                    turtlesSize+=13.2;
                    turtlesNumber+=1;
                    return mv;
                } else return full;
            }
            else return error;
        }
        catch (Exception e) {
            return full;
        }
    }

    @PostMapping("/addAnyAqua")
    public ModelAndView addAnyAqua(@ModelAttribute("anyAqua") AnimalEntity animal) throws Exception{
        try {
            if(animal.getName().equalsIgnoreCase("Penguin")){
                if(anyAquaSize<20.7) {
                    anyAqua.addAnimal(new Penguin());
                    anyAquaSize+=6.9;
                    anyAquaNumber+=1;
                    return mv;
                } else return full;
            } else return error;
        }
        catch (Exception e) {
            return full;
        }
    }

    @GetMapping("/error")
    public String getError(){
        return "error";
    }

    @GetMapping("full")
    public String isFull() {
        return "full";
    }

    @GetMapping("/")
    public String mainPage(Model model){
        model.addAttribute("animal",new AnimalEntity());
        model.addAttribute("tigers",cageForTigers.getAnimals());
        model.addAttribute("tigers_number",cageForTigersNumber);
        model.addAttribute("tigers_size",cageForTigersSize);
        model.addAttribute("wolfs",cageForWolfs.getAnimals());
        model.addAttribute("wolfs_number",cageForWolfsNumber);
        model.addAttribute("wolfs_size",cageForWolfsSize);
        model.addAttribute("birds",birds.getAnimals());
        model.addAttribute("birds_number",birdsNumber);
        model.addAttribute("birds_size",birdsSize);
        model.addAttribute("fish",fish.getAnimals());
        model.addAttribute("fish_number",fishNumber);
        model.addAttribute("fish_size",fishSize);
        model.addAttribute("turtles",turtles.getAnimals());
        model.addAttribute("turtles_number",turtlesNumber);
        model.addAttribute("turtles_size",turtlesSize);
        model.addAttribute("anyAqua",anyAqua.getAnimals());
        model.addAttribute("anyAqua_number",anyAquaNumber);
        model.addAttribute("anyAqua_size",anyAquaSize);
        return "index";
    }
}
