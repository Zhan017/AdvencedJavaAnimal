package com.example.midterm.fishes;

import com.example.midterm.domain.Fish;

public class Pike extends Fish {
    @Override
    public String name() {
        return "Pike";
    }

    @Override
    public Double getComfortableSpace() {
        return 8.8;
    }
}
