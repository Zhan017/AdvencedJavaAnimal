package com.example.midterm.generics;

import com.example.midterm.interfaces.Flyable;

public class Cell<T extends Flyable> extends Habitat<T> {
    public Cell(Double size){ super(size);}
}

