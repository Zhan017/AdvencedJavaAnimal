package com.example.midterm.generics;

import com.example.midterm.interfaces.Walkable;

public class Cage<T extends Walkable> extends Habitat<T> {

    public Cage(Double size) {
        super(size);
    }
}