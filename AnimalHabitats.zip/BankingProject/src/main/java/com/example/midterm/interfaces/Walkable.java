package com.example.midterm.interfaces;

public interface Walkable extends Moveable {
}
