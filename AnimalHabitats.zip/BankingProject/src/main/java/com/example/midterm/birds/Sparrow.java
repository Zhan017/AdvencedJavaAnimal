package com.example.midterm.birds;

import com.example.midterm.domain.Bird;

public class Sparrow extends Bird {
    @Override
    public String name() {
        return "Sparrow";
    }


    @Override
    public Double getComfortableSpace() {
        return 14.2;
    }
}
