package com.example.midterm.interfaces;

public interface Flyable extends Moveable {
}
