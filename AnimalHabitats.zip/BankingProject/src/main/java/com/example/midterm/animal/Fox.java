package com.example.midterm.animal;

import com.example.midterm.domain.Animal;


public class Fox extends Animal {
    @Override
    public String name() {
        return "Fox";
    }

    @Override
    public Double getComfortableSpace() {
        return 9.7;
    }
}