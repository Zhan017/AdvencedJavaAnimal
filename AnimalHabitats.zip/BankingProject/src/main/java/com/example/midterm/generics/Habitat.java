package com.example.midterm.generics;

import com.example.midterm.interfaces.Moveable;

import java.util.ArrayList;
import java.util.List;

public class Habitat<T extends Moveable> {
    Double size;
    private List<T> animals;
    Double sum;

    public void addAnimal(T animal) throws Exception{
        sum += animal.getComfortableSpace();
        if(size < sum){
            sum -= animal.getComfortableSpace();
            throw new Exception("That's error");
        }
        else{ animals.add(animal);}
    }
    public Habitat(Double size) {
        this.size = size;
        animals = new ArrayList<>();
        sum = 0.0;
    }
    public Double getSize() {
        return size;
    }
    public List<T> getAnimals() {
        return animals;
    }
}
