package com.example.midterm.birds;

import com.example.midterm.domain.Bird;
import com.example.midterm.interfaces.Swimable;
import com.example.midterm.interfaces.Walkable;

public class Penguin extends Bird implements Walkable, Swimable {
    @Override
    public String name() {
        return "Penguin";
    }

    @Override
    public Double getComfortableSpace() {
        return 6.9;
    }
}
