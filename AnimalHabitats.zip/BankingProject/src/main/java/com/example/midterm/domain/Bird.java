package com.example.midterm.domain;

import com.example.midterm.interfaces.Flyable;

public abstract class Bird extends Animal implements Flyable {
}
