package com.example.midterm.birds;

import com.example.midterm.domain.Bird;

public class Crow extends Bird {
    @Override
    public String name() {
        return "Crow";
    }


    @Override
    public Double getComfortableSpace() {
        return 4.9;
    }
}
