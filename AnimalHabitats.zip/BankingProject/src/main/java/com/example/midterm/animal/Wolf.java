package com.example.midterm.animal;

import com.example.midterm.domain.Animal;
import com.example.midterm.interfaces.Walkable;

public class Wolf extends Animal implements Walkable {
    @Override
    public String name() {
        return "Wolf";
    }


    @Override
    public Double getComfortableSpace() {
        return 12.1;
    }
}
