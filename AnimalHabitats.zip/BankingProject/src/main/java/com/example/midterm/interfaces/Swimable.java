package com.example.midterm.interfaces;

public interface Swimable extends Moveable {
}
