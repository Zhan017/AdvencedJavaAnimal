package com.example.midterm.fishes;

import com.example.midterm.domain.Fish;

public class Shark extends Fish {
    @Override
    public String name() {
        return "Shark";
    }


    @Override
    public Double getComfortableSpace() {
        return 11.2;
    }
}
