package com.example.midterm.interfaces;

public interface Moveable {
    Double getComfortableSpace();
}
