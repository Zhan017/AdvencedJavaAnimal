package com.example.midterm.animal;

import com.example.midterm.domain.Animal;
import com.example.midterm.interfaces.Swimable;
import com.example.midterm.interfaces.Walkable;

public class Turtle extends Animal implements Walkable, Swimable {
    @Override
    public String name() {
        return "Turtle";
    }

    @Override
    public Double getComfortableSpace() {
        return 13.2;
    }
}
