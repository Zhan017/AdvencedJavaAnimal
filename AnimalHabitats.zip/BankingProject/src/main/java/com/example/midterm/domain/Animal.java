package com.example.midterm.domain;

import com.example.midterm.interfaces.Moveable;

public abstract class Animal implements Moveable {
    abstract public String name();
}
