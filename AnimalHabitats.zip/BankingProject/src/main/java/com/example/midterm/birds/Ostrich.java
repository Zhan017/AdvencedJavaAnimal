package com.example.midterm.birds;

import com.example.midterm.domain.Bird;

public class Ostrich extends Bird {
    @Override
    public String name() {
        return "Ostrich";
    }

    @Override
    public Double getComfortableSpace() {
        return 9.4;
    }
}
