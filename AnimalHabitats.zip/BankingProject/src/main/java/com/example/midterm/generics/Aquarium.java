package com.example.midterm.generics;

import com.example.midterm.interfaces.Swimable;

public class Aquarium<T extends Swimable> extends Habitat<T> {
    public Aquarium(Double size){ super(size);}
}
