package com.example.midterm.animal;

import com.example.midterm.domain.Animal;
import com.example.midterm.interfaces.Walkable;

public class Tiger extends Animal implements Walkable {
    @Override
    public String name() {
        return "TigerService";
    }


    @Override
    public Double getComfortableSpace() {
        return 17.2;
    }
}
